/*
 ============================================================================
 Name        : Hi-buffer.c
 Author      : Luca Santoro 0001005415, 
               Armando Spennato 0001006172,
               Riccardo Bassi 0001084538
 ============================================================================
 Description : Assignment 2 implementation.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>

// CONSTANTS AND MACROS
#define N_THREADS 15
#define N 5              // dimension buffer
#define END_OF_TIME 120  // simulation time
#define FOREVER while(!time_up)

// DEFINITIONS OF NEW DATA TYPES
typedef char thread_name_t[10];

typedef enum {LOW, HIGH} lowhigh_t;
typedef enum {FALSE, TRUE} boolean;

typedef struct {
  int value;
  lowhigh_t p;
  boolean full;
}
value_t;


// MONITOR defined as a new data type
typedef struct {
    value_t buffer[N];   // Buffer of size N
    int in, out;        // Indexes for upload/download operations
    int n_low, n_high;  // Number of full slots of each type

  
    // monitor lock (one mutex lock per monitor)
    pthread_mutex_t m;
    

    // condvars (one condvar per queue)
    pthread_cond_t cv_upload_high, cv_upload_low, cv_download_high, cv_download_low;

  /*
    Queue (condition variables) DESCRIPTION:
    
    cv_upload_high --> A producer thread waits in this queue if the buffer is FULL and 
    the thread priority is HIGH.
    
    cv_upload_low --> A producer thread waits in this queue if the buffer is FULL and 
    the thread priority is LOW.
    
    cv_download_high --> A consumer thread (with HIGH priority (t=HIGH)) waits in this queue if the buffer is EMPTY 
    or when a consumer has high priority (t == HIGH), there is at least one LOW priority item and no HIGH priority 
    item in the shared buffer.
    
    cv_download_low -->  A consumer thread with LOW priority (t=LOW) waits in this queue if the buffer is Empty.
    
 */

    // state variables

    int count; // counter that allows to understand if the buffer is completely full or completely empty

    // For each queue we need to have an associated counter:
    
    //UPLOAD
    int nw_upload_high;   // We need to keep track of suspended threads in the cv_upload_high queue
    int nw_upload_low;    // We need to keep track of suspended threads in the cv_upload_low queue

    //DOWNLOAD 
    int nw_download_high; // We need to keep track of suspended threads in the cv_download_high queue
    int nw_download_low;  // We need to keep track of suspended threads in the cv_download_low queue
    
    
} monitor_t;

// GLOBAL VARIABLES
// We define the monitor as a global variable.
monitor_t mon;

boolean time_up=FALSE;



//  MONITOR API
void upload(monitor_t *mon, char* name, int value, lowhigh_t p);
int download(monitor_t *mon, char* name, lowhigh_t t);
void monitor_init(monitor_t *mon);
void monitor_destroy(monitor_t *mon);

// OTHER FUNCTION DECLARATIONS
// functions corresponding to thread entry points
void *producer(void *arg);
void *consumer(void *arg);

// spend_some_time could be useful to waste an unknown amount of CPU cycles, up to a given top
double spend_some_time(int);
// simulate_action_* to be replaced by function names according to application: e.g., pick_up, put_down, ...
int produce(char* name) { spend_some_time(15); return rand(); }
void consume(char* name, int value) { spend_some_time(15); }

void copy_to_buffer(monitor_t *mon, int value, lowhigh_t p);
int copy_from_buffer(monitor_t *mon, lowhigh_t t);
lowhigh_t f(int value);


// Additional functions to change colors in the terminal view:
// To make the color of the print RED
void red () {
  printf("\033[1;31m");
}

// To make the color of the print GREEN
void green () {
 printf("\033[0;32m");
}

// To make the color of the print CYAN
void cyan () {
 printf("\033[0;36m"); 
}

// To make the color of the print YELLOW
void yellow () {
 printf("\033[0;33m"); 
}

// To reset the color of the print 
void reset () {
  printf("\033[0m");
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// IMPLEMENTATION OF MONITOR API
void upload(monitor_t *mon, char *name, int value, lowhigh_t p) {
    pthread_mutex_lock(&mon->m);

    //****** When BUFFER IS FULL******

/*
     When the buffer is Full we cannot update an item into the buffer.
     In this situation when there is an empty slot we have to give the priority
     in upload to the uploader with HIGH priority.
     So, THE IDEA is the following:
     When the buffer is full, taking into account the priority we stack the uploading request
     into two different queue, that are cv_upload_high and cv_upload_low. With the correct 
     release from the previous queues, we are able to handle the priority in upload in a correct way.

     We release the requests from these queues in the download function.

*/

// if the time is not over 
    while (time_up== FALSE && mon->count==N) { //  (mon->in+1)%N==mon->out
      
     if(p==HIGH){ 
         
        yellow();
         
        printf("\n%s *** WAITING in Upload ***  (%s)\n", name, p == LOW?"LOW":"HIGH");
        
        reset();
         
         
        mon->nw_upload_high++;
        printf("\nINFO:[nw_upload_high], HIGH Uploaders waiting due to buffer FULL (IN): %d\n",mon->nw_upload_high);
        pthread_cond_wait(&mon->cv_upload_high,&mon->m);
        mon->nw_upload_high--;
        printf("INFO:[nw_upload_high],HIGH Uploaders waiting due to buffer FULL (OUT): %d\n",mon->nw_upload_high);
        
       }
       else {
           
        yellow();
        
        printf("\n%s *** WAITING in Upload ***  (%s)\n", name, p == LOW?"LOW":"HIGH");
        
        reset();
           
           
           
        mon->nw_upload_low++;
        printf("INFO:[nw_upload_low], LOW Uploaders waiting due to buffer FULL (IN): %d\n",mon->nw_upload_low);
        pthread_cond_wait(&mon->cv_upload_low,&mon->m);
        mon->nw_upload_low--;
        printf("INFO:[nw_upload_low], LOW Uploaders waiting due to buffer FULL (OUT): %d\n",mon->nw_upload_low);
        
         }
    }
    
 //  If multiple tasks are waiting to upload, then upload requests with p equal to HIGH have the priority.
  
 // We need to take into account the time. When the END_OF_TIME is reached (time is out) we unlock waiting downloaders, unlock the mutex and terminate thread
 
    if(time_up==TRUE){
        
        green();
        printf("\nEND_OF_TIME Download\n ");
        reset();
        
        pthread_cond_signal(&mon->cv_download_high);
        pthread_cond_signal(&mon->cv_download_low);
        pthread_mutex_unlock(&mon->m);
        pthread_exit(NULL);
    }



    // *********buffer is NOT FULL (there is at least one empty slot)******
    
    // Now we insert an item and unblock consumer

    
    copy_to_buffer(mon,value,p); // we insert an item into the buffer
    
    red();
    
    printf("\n%s ----------> UPLOADED <----------  (%s)\t(%d)\n", name, p == LOW?"LOW":"HIGH",value);//
    
    reset();
    
   
    mon->count++; // we increment the counter, because we have upload an element in the buffer


    // **We show the buffer in upload**
    printf("\nUPDATING Buffer in Upload:\n");
    int i;
    for(i=0;i<N;i++){
      printf("Buffer position [%d] Value: %d \t Priority:  %s \n",i,mon->buffer[i].value,mon->buffer[i].p==LOW?"LOW":"HIGH");
    }

    // We UNLOCK CONSUMER (DOWNLOADER)
    
    /*
    when a producer thread finishes uploading a value to the shared buffer, it as
    first step signals to waiting consumer threads in the download queue HIGH (cv_download_high)
    if there is an item  with HIGH priority (p=HIGH) in the shared buffer. If there is no waiting consumer
    threads at the HIGH queue or there are only item with LOW priority in the buffer (p=LOW), it signals 
    to waiting consumer threads in the download queue LOW (cv_download_low) only if there are waiting
    consumer threads in this queue.
    */
    
    
    // we give priority to the high consumer threads to avoid starvation
    if (mon->nw_download_high > 0 && mon->n_high > 0 ){// at least an element in cv_download_high
      pthread_cond_signal(&mon->cv_download_high);
    }
    else if ( mon->nw_download_low > 0){ 
        //in this case we can fetch a low/high element from the buffer
     pthread_cond_signal(&mon->cv_download_low);
    }
    
    // To visualize n_low and n_high inside the buffer
    printf("n_low: %d \t",mon->n_low);
    printf("n_high: %d \n",mon->n_high);

   pthread_mutex_unlock(&mon->m);

}





int download(monitor_t *mon, char *name, lowhigh_t t) {
  int retval;
    pthread_mutex_lock(&mon->m); // We take the lock
    
    // When the buffer is EMPTY or does not contain an integer with p >= t, then the calling task has to wait
    
    /*
    
   POSSIBLE COMBINATIONS:
                    t                  p
   DOWNLOADER--> (HIGH)  BUFFER --> (HIGH) *OK*
   DOWNLOADER--> (LOW)   BUFFER --> (HIGH) *OK*
   DOWNLOADER--> (LOW)   BUFFER --> (LOW)  *OK* 
   DOWNLOADER--> (HIGH)  BUFFER --> (LOW)  *WE HAVE TO WAIT!*

   We can have 2^(2) different combinations.
   We can observe that:
   - if t==HIGH the consumer can only consume one item HIGH.
   - if t==LOW  the consumer can consume an item from the buffer 
    in both case, LOW/HIGH priority.
    
   */
    
    while(time_up==FALSE && ((mon->count==0) || (t==HIGH && mon->n_high==0 && mon->n_low>0))){ // mon->in==mon->out
    
        yellow();
        
        printf("\n%s *** WAITING in Download ***  (%s)\n", name, t == LOW?"LOW":"HIGH");
        
        reset();
        
     if(t==LOW){
        mon ->nw_download_low++;
        printf("\nINFO:[nw_download_low],Downloaders LOW waiting due to buffer EMPTY or no p>=t(IN): %d\n",mon->nw_download_low); //  
        pthread_cond_wait(&mon->cv_download_low,&mon->m);
        mon ->nw_download_low--;
        printf("\nINFO:[nw_download_low],Downloaders LOW waiting due to buffer EMPTY or no p>=t (OUT): %d\n",mon->nw_download_low); //  
       }


       else{
        mon->nw_download_high++;
        printf("\nINFO:[nw_download_high],Downloaders HIGH waiting due to buffer EMPTY o no p>=t (IN): %d\n",mon->nw_download_high); // 
        pthread_cond_wait(&mon->cv_download_high,&mon->m);
        mon->nw_download_high--;
        printf("\nINFO:[nw_download_high],Downloaders HIGH waiting due to buffer EMPTY o no p>=t (OUT): %d\n",mon->nw_download_high); // 
        }

}


// We need to take into account the time. When the END_OF_TIME is reached (time is out) we unlock waiting uploaders, unlock the mutex and terminate thread
    
    if (time_up == TRUE) {
        
        red();
        printf("\nEND_OF_TIME Upload\n");
        reset();
        
        pthread_cond_signal(&mon->cv_upload_high);
        pthread_cond_signal(&mon->cv_upload_low);
        pthread_mutex_unlock(&mon->m);
        pthread_exit(NULL);
    }

 // ***Buffer is NOT EMPTY***

 // Now we can consume an item.
    
    retval=copy_from_buffer(mon,t); // we remove an item from the buffer
    
     green();
    
    printf("%s ----------> DOWNLOADED <----------  (%s)\t(%d)\n", name, t == LOW?"LOW":"HIGH",retval);
    
    reset();


    mon->count--; // we decrement the counter because we just took an element

   // We UNLOCK PRODUCER (UPLOADER)
   
   /*
   when a consumer thread finishes downloading an item from the shared buffer, it signals to waiting producer
   threads in the upload queue HIGH (cv_upload_high). In the case there is no waiting threads
   in this queue, it signals to waiting threads in the upload queue LOW (cv_upload_low).
   */
   
   // We give the priority at the queue that contains HIGH producers.
    if (mon->nw_upload_high>0 ){                   // if we have at least one item in cv_upload_high
        pthread_cond_signal(&mon->cv_upload_high); // we give precedence to cv_upload_hight
    }
    // In the case we have no producer with higher priority (only LOW)
    else if (mon->nw_upload_low>0 && mon->nw_upload_high==0){  // if we have no element in the cv_upload_hight
      pthread_cond_signal(&mon->cv_upload_low);               // we give the priority at the cv_upload_low queue
    }

    pthread_mutex_unlock(&mon->m);  // we release the lock
    return retval;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void monitor_init(monitor_t *mon) {
    // set initial value of monitor data structures, state variables, mutexes, counters, etc.
    // typically can use default attributes for monitor mutex and condvars
  int i;
    for(i=0;i<N;i++){
      mon->buffer[i].full=FALSE;
    }
    
    // we set all the condvar counters to 0
    // Upload
    mon->nw_upload_low=0;
    mon->nw_upload_high=0;
    //Download
    mon->nw_download_low=0;
    mon->nw_download_high=0;
    
   
    // initialize other counters/indexes
    mon-> count=0;
    mon->in=0;
    mon->out=0;
    
    // we initialize our condvar and our mutex
    pthread_cond_init(&mon->cv_upload_high,NULL);
    pthread_cond_init(&mon->cv_download_low,NULL);
    pthread_cond_init(&mon->cv_upload_low,NULL);
    pthread_cond_init(&mon->cv_download_high,NULL);
    pthread_mutex_init(&mon->m,NULL);
}

void monitor_destroy(monitor_t *mon) {

     // We destroy our condvar
    pthread_cond_destroy(&mon->cv_upload_high);
    pthread_cond_destroy(&mon->cv_download_low);
    pthread_cond_destroy(&mon->cv_upload_low);
    pthread_cond_destroy(&mon->cv_download_high);
    // we destroy the mutex
    pthread_mutex_destroy(&mon->m);
}

// MAIN FUNCTION
int main(void) {
    // thread management data structures
    pthread_t my_threads[N_THREADS];
    thread_name_t my_thread_names[N_THREADS];
    int i;

    // initialize monitor data structure before creating the threads
    monitor_init(&mon);


for (i=0;i<N_THREADS/2;i++) {
        sprintf(my_thread_names[i],"p%d",i);
        // create N_THREADS thread with same entry point
        // these threads are distinguishable thanks to their argument (their name: "t1", "t2", ...)
        // thread names can also be used inside threads to show output messages
        pthread_create(&my_threads[i], NULL, producer, my_thread_names[i]);
    }

for (;i<N_THREADS;i++) {
        sprintf(my_thread_names[i],"c%d",i);
        // create N_THREADS thread with same entry point
        // these threads are distinguishable thanks to their argument (their name: "t1", "t2", ...)
        // thread names can also be used inside threads to show output messages
        pthread_create(&my_threads[i], NULL, consumer, my_thread_names[i]);
    }

    sleep(END_OF_TIME);
    time_up=TRUE;

    cyan();
    printf("\n\n*** END_OF_TIME ***\nWaiting tasks:\nnw_upload_high:%d, nw_upload_low:%d,\nnw_download_low:%d, nw_download_high:%d\n", 
            mon.nw_upload_high, mon.nw_upload_low, mon.nw_download_low, mon.nw_download_high);//
    reset();
    
    // Join threads
    for (i=0;i<N_THREADS;i++) {
        pthread_join(my_threads[i], NULL);
        printf("JOIN %s\n", (char*) my_thread_names[i]);//
    }

    // We destroy monitor    
    monitor_destroy(&mon);
    printf("MONITOR was destroyed");

    return EXIT_SUCCESS;
}

void *producer(void *arg) {
  char *name=arg;
    int value;
    lowhigh_t p;
    FOREVER {
        value = produce(name);
        p = f(value);
        printf("\nproducer %s: uploading value %d (%s)\n", name, value, p==LOW?"LOW":"HIGH");
        upload(&mon, name, value, p);
        //spend_some_time(2);
    }
    //printf("Terminating producer %s \n",name); //
    pthread_exit(NULL);
}


void *consumer(void *arg) {
  char *name=arg;
    int value;
    lowhigh_t threshold;
    threshold=rand()%2;
    printf("\nI am consumer %s (%s)\n", name, threshold==LOW?"LOW":"HIGH");
    FOREVER {
        value = download(&mon, name, threshold);
        printf("consumer %s: downloaded value %d\n", name, value);
        consume(name,value);
        //spend_some_time(2);
    }
    
    //printf("Terminating consumer %s \n",name); 
    pthread_exit(NULL);
}



// AUXILIARY FUNCTIONS
double spend_some_time(int max_steps) {
    double x, sum=0.0, step;
    long i, N_STEPS=rand()%(max_steps*1000000);
    step = 1/(double)N_STEPS;
    for(i=0; i<N_STEPS; i++) {
        x = (i+0.5)*step;
        sum+=4.0/(1.0+x*x);
    }
    return step*sum;
}

lowhigh_t f(int value) {
  lowhigh_t p=(lowhigh_t) rand()%2;
  printf("\nf(%d)=%s\n", value, p==LOW?"LOW":"HIGH");
  return p;
}

void copy_to_buffer(monitor_t *mon, int value, lowhigh_t p) {
  int count=0;
  while(mon->buffer[mon->in].full) { // in is the index that allows us to scroll the buffer in upload 

    mon->in=(mon->in+1)%N;

    if(++count>N) {
      perror("buffer is inconsistent");
      abort();
    }
  }
  printf("\nPosition in: %d\n",mon->in); // To see where the copy_to_buffer function points in the buffer 
  mon->buffer[mon->in].value=value;
  mon->buffer[mon->in].p=p;
  mon->buffer[mon->in].full=TRUE;
  if(p==HIGH)
    mon->n_high++;
  else mon->n_low++;

 
}

int copy_from_buffer(monitor_t *mon, lowhigh_t t) {
  int retval, count=0;
  while((mon->buffer[mon->out].full==FALSE)||(mon->buffer[mon->out].p<t)) {

    mon->out=(mon->out+1)%N;

        if(++count>N) {
            perror("buffer is inconsistent");
            abort();
        }
    }
  printf("\nPosition out: %d\n",mon->out); // To see where the copy_from_buffer function points in the buffer 
  retval=mon->buffer[mon->out].value;
  mon->buffer[mon->out].value=2;          // When we take a value from the buffer we put the number 2 in the 
                                          // same position to understand that we have already taken an item.
  mon->buffer[mon->out].full=FALSE;
  if(mon->buffer[mon->out].p==HIGH)
    mon->n_high--;
  else mon->n_low--;

  return retval;
  
}














